# Terencios Refrigeração — modo offline e Android

## O que foi preparado
- Persistência local de agendamentos em IndexedDB.
- Criação, edição e exclusão offline com fila de sincronização.
- Envio da fila quando a conexão voltar e o aplicativo estiver aberto/retomar ao primeiro plano.
- Relatório semanal calculado localmente quando a API estiver indisponível.
- Cache do app shell (HTML, JavaScript, CSS e ícones) para permitir reabrir o PWA sem internet depois da primeira carga online.
- Configuração inicial do Capacitor para empacotar o frontend em aplicativo Android nativo, sem barra de endereço do navegador.

## Gerar o projeto Android
No computador com Node.js LTS e Android Studio instalados:

```bash
cd frontend
npm install
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

No Android Studio, aguarde o Gradle sincronizar. Para gerar APK de teste: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Para distribuição, configure uma chave de assinatura em **Build > Generate Signed Bundle / APK**.

## Importante sobre os dados offline
1. Abra o aplicativo com internet pelo menos uma vez e aguarde a agenda/histórico carregar para gravar os registros existentes no aparelho.
2. Depois disso, os registros ficam disponíveis localmente e as alterações feitas sem internet entram na fila.
3. Ao voltar a internet, a fila é enviada automaticamente quando o app está aberto ou volta ao primeiro plano. Não depende de sincronização em segundo plano com o app totalmente encerrado.
4. O armazenamento offline fica neste aparelho/navegador. Limpar os dados do app ou desinstalar pode apagar alterações ainda não sincronizadas. Não desinstale enquanto houver pendências.
5. O backend continua sendo necessário para compartilhar os mesmos dados entre aparelhos. A versão offline mantém uma cópia local; não substitui o servidor.

## Segurança
Os arquivos `.env` e dependências `node_modules` não fazem parte deste pacote. Configure as variáveis de ambiente do backend no ambiente de implantação, sem publicar credenciais.


## Login compartilhado
Consulte `LOGIN-E-SINCRONIZACAO.md` para publicar a API, configurar os dois usuários e ativar a sincronização entre celulares.
