from datetime import date as Date, timedelta
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query

from lib.dates import today_iso
from lib.db import db
from models.appointment import (
    Appointment,
    AppointmentCreate,
    AppointmentPatch,
    DayRevenue,
    MethodTotal,
    TodayInfo,
    WeekHistory,
    WeeklyReport,
)

router = APIRouter()

DAY_LABELS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]


def _monday(d: Date) -> Date:
    return d - timedelta(days=d.weekday())


async def _get_or_404(id: str) -> dict:
    doc = await db.appointments.find_one({"id": id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado")
    return doc


@router.get("/today", response_model=TodayInfo)
async def get_today():
    t = Date.fromisoformat(today_iso())
    return TodayInfo(today=t.isoformat(), week_start=_monday(t).isoformat())


@router.get("/appointments", response_model=List[Appointment])
async def list_appointments(
    date_from: Optional[str] = Query(default=None, alias="from"),
    date_to: Optional[str] = Query(default=None, alias="to"),
    status: Optional[str] = None,
):
    q: dict = {}
    if date_from or date_to:
        q["date"] = {}
        if date_from:
            q["date"]["$gte"] = date_from
        if date_to:
            q["date"]["$lte"] = date_to
    if status:
        q["status"] = status
    docs = await db.appointments.find(q, {"_id": 0}).sort([("date", 1), ("time", 1)]).to_list(5000)
    return [Appointment(**d) for d in docs]


@router.post("/appointments", response_model=Appointment, status_code=201)
async def create_appointment(body: AppointmentCreate):
    appt = Appointment(**body.model_dump())
    await db.appointments.insert_one(appt.model_dump())
    return appt


@router.get("/appointments/{id}", response_model=Appointment)
async def get_appointment(id: str):
    return Appointment(**(await _get_or_404(id)))


@router.put("/appointments/{id}", response_model=Appointment)
async def update_appointment(id: str, body: AppointmentCreate):
    await _get_or_404(id)
    await db.appointments.update_one({"id": id}, {"$set": body.model_dump()})
    return Appointment(**(await _get_or_404(id)))


@router.patch("/appointments/{id}", response_model=Appointment)
async def patch_appointment(id: str, body: AppointmentPatch):
    await _get_or_404(id)
    changes = body.model_dump(exclude_unset=True, exclude_none=True)
    if changes:
        await db.appointments.update_one({"id": id}, {"$set": changes})
    return Appointment(**(await _get_or_404(id)))


@router.delete("/appointments/{id}", status_code=204)
async def delete_appointment(id: str):
    res = await db.appointments.delete_one({"id": id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado")


@router.get("/reports/weekly", response_model=WeeklyReport)
async def weekly_report(date: Optional[str] = None):
    today = Date.fromisoformat(today_iso())
    try:
        ref = Date.fromisoformat(date) if date else today
    except ValueError:
        raise HTTPException(status_code=400, detail="Data inválida (use AAAA-MM-DD)")
    start = _monday(ref)
    end = start + timedelta(days=6)
    hist_start = start - timedelta(weeks=7)

    docs = await db.appointments.find(
        {"date": {"$gte": hist_start.isoformat(), "$lte": end.isoformat()}}, {"_id": 0}
    ).to_list(10000)

    week_docs = [d for d in docs if start.isoformat() <= d["date"] <= end.isoformat()]
    done = [d for d in week_docs if d["status"] == "concluido"]
    faturado = sum(d["price"] for d in done)
    recebido = sum(d["price"] for d in done if d.get("is_paid"))

    days = []
    for i in range(7):
        day = (start + timedelta(days=i)).isoformat()
        day_done = [d for d in done if d["date"] == day]
        days.append(DayRevenue(date=day, label=DAY_LABELS[i], faturado=sum(d["price"] for d in day_done), count=len(day_done)))

    methods: dict[str, MethodTotal] = {}
    for d in done:
        m = d.get("payment_method") or "A combinar"
        mt = methods.setdefault(m, MethodTotal(method=m, total=0, count=0))
        mt.total += d["price"]
        mt.count += 1

    history = []
    for w in range(8):
        ws = hist_start + timedelta(weeks=w)
        we = ws + timedelta(days=6)
        wd = [d for d in docs if ws.isoformat() <= d["date"] <= we.isoformat() and d["status"] == "concluido"]
        history.append(
            WeekHistory(
                week_start=ws.isoformat(),
                week_end=we.isoformat(),
                faturado=sum(d["price"] for d in wd),
                recebido=sum(d["price"] for d in wd if d.get("is_paid")),
                count=len(wd),
            )
        )

    return WeeklyReport(
        week_start=start.isoformat(),
        week_end=end.isoformat(),
        is_current=start == _monday(today),
        faturado=faturado,
        recebido=recebido,
        a_receber=faturado - recebido,
        servicos_concluidos=len(done),
        ticket_medio=faturado / len(done) if done else 0,
        agendados=sum(1 for d in week_docs if d["status"] == "agendado"),
        cancelados=sum(1 for d in week_docs if d["status"] == "cancelado"),
        days=days,
        payment_methods=sorted(methods.values(), key=lambda m: -m.total),
        history=history,
    )
