import uuid
from datetime import datetime, timezone
from typing import List, Literal, Optional

from pydantic import BaseModel, Field

Status = Literal["agendado", "concluido", "cancelado"]

DATE_RE = r"^\d{4}-\d{2}-\d{2}$"
TIME_RE = r"^\d{2}:\d{2}$"


class AppointmentCreate(BaseModel):
    client_name: str = Field(min_length=1)
    client_phone: str = ""
    address: str = ""
    service_type: str = Field(min_length=1)
    equipment: str = ""
    date: str = Field(pattern=DATE_RE)
    time: str = Field(pattern=TIME_RE)
    price: float = Field(ge=0)
    payment_method: str = "A combinar"
    is_paid: bool = False
    status: Status = "agendado"
    notes: str = ""


class AppointmentPatch(BaseModel):
    client_name: Optional[str] = Field(default=None, min_length=1)
    client_phone: Optional[str] = None
    address: Optional[str] = None
    service_type: Optional[str] = Field(default=None, min_length=1)
    equipment: Optional[str] = None
    date: Optional[str] = Field(default=None, pattern=DATE_RE)
    time: Optional[str] = Field(default=None, pattern=TIME_RE)
    price: Optional[float] = Field(default=None, ge=0)
    payment_method: Optional[str] = None
    is_paid: Optional[bool] = None
    status: Optional[Status] = None
    notes: Optional[str] = None


class Appointment(AppointmentCreate):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class TodayInfo(BaseModel):
    today: str
    week_start: str


class DayRevenue(BaseModel):
    date: str
    label: str
    faturado: float
    count: int


class MethodTotal(BaseModel):
    method: str
    total: float
    count: int


class WeekHistory(BaseModel):
    week_start: str
    week_end: str
    faturado: float
    recebido: float
    count: int


class WeeklyReport(BaseModel):
    week_start: str
    week_end: str
    is_current: bool
    faturado: float
    recebido: float
    a_receber: float
    servicos_concluidos: int
    ticket_medio: float
    agendados: int
    cancelados: int
    days: List[DayRevenue]
    payment_methods: List[MethodTotal]
    history: List[WeekHistory]
