"""Seed demo appointments (only when the collection is empty). Run: cd /app/backend && python seed.py"""
import asyncio
from datetime import date, timedelta

from lib.dates import today_iso
from lib.db import db, ensure_indexes
from models.appointment import Appointment

DEMO = [
    # (day offset, time, client, phone, address, service, equipment, price, method, paid, status)
    (0, "09:00", "Mariana Souza", "(11) 98765-4321", "Rua das Palmeiras, 120 - Apto 42, São Paulo", "Higienização / Limpeza", "Split 12.000 BTUs", 220, "Pix", False, "agendado"),
    (0, "14:30", "Padaria Pão Quente", "(11) 97654-1234", "Av. Brasil, 1500, São Paulo", "Manutenção Preventiva", "2x Split 18.000 BTUs", 380, "Pix", False, "agendado"),
    (1, "10:00", "Carlos Henrique", "(11) 99876-5432", "Rua Augusta, 900, São Paulo", "Instalação", "Inverter 9.000 BTUs", 650, "Cartão de Crédito", False, "agendado"),
    (3, "08:30", "Clínica Bem Estar", "(11) 93456-7890", "Rua Vergueiro, 2200, São Paulo", "Reparo / Conserto", "Cassete 36.000 BTUs", 480, "Boleto", False, "agendado"),
    (-1, "15:00", "Ana Paula Lima", "(11) 91234-5678", "Rua Oscar Freire, 300, São Paulo", "Carga de Gás", "Split 12.000 BTUs", 300, "Dinheiro", True, "concluido"),
    (-2, "09:30", "Roberto Alves", "(11) 92345-6789", "Rua Haddock Lobo, 45, São Paulo", "Higienização / Limpeza", "Split 9.000 BTUs", 200, "Pix", True, "concluido"),
    (-3, "11:00", "Escritório Contábil Silva", "(11) 94567-8901", "Av. Paulista, 1000 - Sala 12, São Paulo", "Manutenção Preventiva", "3x Split 12.000 BTUs", 540, "Pix", False, "concluido"),
    (-8, "10:00", "Fernanda Rocha", "(11) 95678-9012", "Rua Bela Cintra, 700, São Paulo", "Instalação", "Inverter 12.000 BTUs", 700, "Cartão de Débito", True, "concluido"),
    (-10, "16:00", "João Pedro", "(11) 96789-0123", "Rua Consolação, 88, São Paulo", "Higienização / Limpeza", "Split 9.000 BTUs", 180, "Pix", True, "concluido"),
    (-15, "09:00", "Mercado Bom Preço", "(11) 97890-1234", "Av. Ipiranga, 300, São Paulo", "Reparo / Conserto", "Piso-teto 30.000 BTUs", 850, "Pix", True, "concluido"),
    (-17, "13:00", "Luciana Martins", "(11) 98901-2345", "Rua Frei Caneca, 410, São Paulo", "Instalação", "Split 18.000 BTUs", 750, "Cartão de Crédito", True, "concluido"),
    (-22, "10:30", "Pedro Santos", "(11) 99012-3456", "Rua Teodoro Sampaio, 50, São Paulo", "Manutenção Preventiva", "Split 12.000 BTUs", 250, "Dinheiro", True, "concluido"),
    (-24, "14:00", "Restaurante Sabor", "(11) 90123-4567", "Rua dos Pinheiros, 600, São Paulo", "Higienização / Limpeza", "4x Split 24.000 BTUs", 900, "Pix", True, "concluido"),
    (-30, "09:00", "Gabriel Costa", "(11) 91122-3344", "Rua Cardeal Arcoverde, 77, São Paulo", "Carga de Gás", "Split 9.000 BTUs", 280, "Pix", True, "concluido"),
    (-36, "11:00", "Beatriz Nunes", "(11) 92233-4455", "Rua Mourato Coelho, 12, São Paulo", "Instalação", "Inverter 24.000 BTUs", 950, "Cartão de Crédito", True, "concluido"),
    (-43, "15:30", "Thiago Ribeiro", "(11) 93344-5566", "Rua Fradique Coutinho, 200, São Paulo", "Reparo / Conserto", "Split 12.000 BTUs", 320, "Pix", True, "concluido"),
    (-5, "10:00", "Marcos Vieira", "(11) 94455-6677", "Rua Cristiano Viana, 33, São Paulo", "Higienização / Limpeza", "Split 9.000 BTUs", 200, "Pix", False, "cancelado"),
]


async def main():
    await ensure_indexes()
    if await db.appointments.count_documents({}) > 0:
        print("appointments already present, skipping seed")
        return
    today = date.fromisoformat(today_iso())
    docs = []
    for off, t, name, phone, addr, svc, eq, price, method, paid, status in DEMO:
        docs.append(
            Appointment(
                client_name=name, client_phone=phone, address=addr, service_type=svc, equipment=eq,
                date=(today + timedelta(days=off)).isoformat(), time=t, price=price,
                payment_method=method, is_paid=paid, status=status, notes="",
            ).model_dump()
        )
    await db.appointments.insert_many(docs)
    print(f"seeded {len(docs)} appointments")


if __name__ == "__main__":
    asyncio.run(main())
