"""Shared username/password authentication for the Terencios team."""
import os
from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from passlib.context import CryptContext
from pydantic import BaseModel, Field

from lib.db import db

JWT_SECRET = os.environ.get("JWT_SECRET_KEY", "")
JWT_ALGORITHM = "HS256"
COOKIE_NAME = "terencios_session"
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "true").lower() == "true"
COOKIE_SAMESITE = "none" if COOKIE_SECURE else "lax"
SESSION_DAYS = int(os.environ.get("SESSION_DAYS", "30"))
password_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
router = APIRouter()


class LoginBody(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)


def _token(username: str) -> str:
    if not JWT_SECRET:
        raise HTTPException(status_code=503, detail="Autenticação ainda não configurada no servidor")
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": username, "iat": now, "exp": now + timedelta(days=SESSION_DAYS)}, JWT_SECRET, algorithm=JWT_ALGORITHM)


async def get_current_user(request: Request) -> str:
    token: Optional[str] = request.cookies.get(COOKIE_NAME)
    if not token or not JWT_SECRET:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Faça login para continuar")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username = payload.get("sub")
        if not username or not await db.users.find_one({"username": username}, {"_id": 1}):
            raise ValueError("invalid user")
        return str(username)
    except (jwt.PyJWTError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sessão inválida. Entre novamente.")


@router.post("/auth/login")
async def login(body: LoginBody, response: Response):
    user = await db.users.find_one({"username": body.username.strip().lower()})
    if not user or not password_context.verify(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Usuário ou senha incorretos")
    token = _token(user["username"])
    response.set_cookie(
        key=COOKIE_NAME, value=token, httponly=True, secure=COOKIE_SECURE,
        samesite=COOKIE_SAMESITE, max_age=SESSION_DAYS * 24 * 60 * 60,
        path="/",
    )
    return {"username": user["username"]}


@router.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie(key=COOKIE_NAME, path="/", secure=COOKIE_SECURE, httponly=True, samesite=COOKIE_SAMESITE)
    return {"ok": True}


@router.get("/auth/me")
async def me(username: str = Depends(get_current_user)):
    return {"username": username}


async def ensure_auth_users() -> None:
    if not JWT_SECRET:
        raise RuntimeError("Defina JWT_SECRET_KEY nas variáveis do servidor")
    pairs = [
        (os.environ.get("ADMIN_USERNAME", ""), os.environ.get("ADMIN_PASSWORD", "")),
        (os.environ.get("PARTNER_USERNAME", ""), os.environ.get("PARTNER_PASSWORD", "")),
    ]
    if any(not username or not password for username, password in pairs):
        raise RuntimeError("Defina ADMIN_USERNAME, ADMIN_PASSWORD, PARTNER_USERNAME e PARTNER_PASSWORD")
    for username, password in pairs:
        username = username.strip().lower()
        if len(username) < 3 or len(password) < 8:
            raise RuntimeError("Cada usuário deve ter ao menos 3 caracteres e cada senha 8 caracteres")
        await db.users.update_one(
            {"username": username},
            {"$setOnInsert": {"username": username, "password_hash": password_context.hash(password)}},
            upsert=True,
        )
