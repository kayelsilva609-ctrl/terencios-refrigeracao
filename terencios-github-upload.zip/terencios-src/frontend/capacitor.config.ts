import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'br.com.terencios.refrigeracao',
  appName: 'Terencios Refrigeração',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: { backgroundColor: '#0B1120' },
  plugins: {
    StatusBar: { overlaysWebView: false, backgroundColor: '#0B1120', style: 'DARK' },
    SplashScreen: { launchShowDuration: 0, backgroundColor: '#0B1120' }
  }
};
export default config;
