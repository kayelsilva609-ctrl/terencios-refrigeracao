import { useState } from "react";
import type { FormEvent } from "react";
import { Navigate } from "react-router-dom";
import { Snowflake, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { hasRemoteApi } from "@/lib/api";

export default function Login() {
  const { username: currentUser, loading, login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  if (loading) return <div className="min-h-screen grid place-items-center bg-[#0B1120] text-slate-300">Carregando...</div>;
  if (currentUser) return <Navigate to="/" replace />;

  async function submit(event: FormEvent) {
    event.preventDefault(); setError(""); setBusy(true);
    try { await login(username.trim(), password); }
    catch (e) { setError(e instanceof Error ? e.message : "Não foi possível entrar. Confira usuário e senha."); }
    finally { setBusy(false); }
  }

  return <main className="min-h-screen grid place-items-center bg-[#0B1120] px-5 py-10 text-white">
    <form onSubmit={submit} className="w-full max-w-sm rounded-3xl border border-sky-900/60 bg-slate-900/80 p-7 shadow-2xl">
      <div className="mx-auto mb-5 grid size-14 place-items-center rounded-2xl bg-sky-600"><Snowflake className="size-8" /></div>
      <h1 className="text-center text-2xl font-bold">Terencios Refrigeração</h1>
      <p className="mb-7 mt-2 text-center text-sm text-slate-400">Entre com seu usuário e senha</p>
      {!hasRemoteApi && <p className="mb-4 rounded-xl border border-amber-700/50 bg-amber-950/40 p-3 text-sm text-amber-200">O servidor compartilhado ainda não está conectado. Configure a URL do servidor para ativar os logins e a sincronização entre celulares.</p>}
      <label className="mb-2 block text-sm text-slate-300" htmlFor="username">Usuário</label>
      <input id="username" autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} required className="mb-4 h-12 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 outline-none focus:border-sky-500" />
      <label className="mb-2 block text-sm text-slate-300" htmlFor="password">Senha</label>
      <input id="password" type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} required className="mb-4 h-12 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 outline-none focus:border-sky-500" />
      {error && <p role="alert" className="mb-4 text-sm text-rose-300">{error}</p>}
      <Button type="submit" disabled={busy || !hasRemoteApi} className="h-12 w-full"><LogIn className="mr-2 size-4" />{busy ? "Entrando..." : "Entrar"}</Button>
      <p className="mt-5 text-center text-xs text-slate-500">Acesso exclusivo da equipe</p>
    </form>
  </main>;
}
