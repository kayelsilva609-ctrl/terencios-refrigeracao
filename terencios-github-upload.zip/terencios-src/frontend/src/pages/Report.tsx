import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from "recharts";
import { CheckCircle2, ChevronLeft, ChevronRight, CircleDollarSign, Clock3, Receipt, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWeeklyReport } from "@/lib/queries";
import { brl, fmtDate, shiftDate, shortRange } from "@/lib/format";
import type { WeeklyReport } from "@/lib/types";
import { cn } from "@/lib/utils";

function shareText(r: WeeklyReport) {
  return [
    `*Relatório semanal — ${shortRange(r.week_start, r.week_end)}*`,
    `Faturado: ${brl(r.faturado)}`,
    `Recebido: ${brl(r.recebido)}`,
    `A receber: ${brl(r.a_receber)}`,
    `Serviços concluídos: ${r.servicos_concluidos}`,
    `Ticket médio: ${brl(r.ticket_medio)}`,
  ].join("\n");
}

const tooltipStyle = { background: "#0F182B", border: "1px solid #1E293B", borderRadius: 10, color: "#F8FAFC" };

export default function Report() {
  const [ref, setRef] = useState<string | null>(null);
  const { data, isLoading, isError } = useWeeklyReport(ref);
  const r = !isError ? data : undefined;

  const prevWeeks = r?.history.slice(0, -1) ?? [];
  const prevAvg = prevWeeks.length ? prevWeeks.reduce((s, w) => s + w.faturado, 0) / prevWeeks.length : 0;
  const lastWeek = prevWeeks.at(-1)?.faturado ?? 0;
  const diff = r && lastWeek > 0 ? ((r.faturado - lastWeek) / lastWeek) * 100 : null;

  const stats = r
    ? [
        { key: "revenue", label: "Total faturado", sub: "serviços concluídos", value: brl(r.faturado), icon: CircleDollarSign, cls: "bg-[#092E2B] border-emerald-800/40 text-emerald-300" },
        { key: "received", label: "Recebido", sub: "pagos", value: brl(r.recebido), icon: CheckCircle2, cls: "bg-[#0F2444] border-sky-800/50 text-sky-300" },
        { key: "pending", label: "A receber", sub: "concluídos não pagos", value: brl(r.a_receber), icon: Clock3, cls: "bg-[#2A1F0D] border-amber-800/40 text-amber-300" },
        { key: "count", label: "Serviços", sub: `ticket médio ${brl(r.ticket_medio)}`, value: String(r.servicos_concluidos), icon: Receipt, cls: "bg-[#111B30] border-slate-800 text-slate-100" },
      ]
    : [];

  return (
    <div className="space-y-6">
      <section className="flex flex-col sm:flex-row sm:items-end gap-4 animate-rise">
        <div>
          <p className="text-sm text-sky-300/80">Faturamento de segunda a domingo</p>
          <h1 className="font-heading text-3xl sm:text-4xl font-bold tracking-tight mt-1">Relatório semanal</h1>
        </div>
        {r && (
          <a
            href={`https://wa.me/?text=${encodeURIComponent(shareText(r))}`}
            target="_blank"
            rel="noreferrer"
            className="sm:ml-auto inline-flex h-10 items-center gap-2 rounded-lg border border-emerald-600/40 bg-emerald-600/10 px-4 text-sm font-medium text-emerald-300 hover:bg-emerald-600/20 transition-colors duration-150"
            data-testid="report-share-whatsapp"
          >
            <Share2 className="size-4" /> Enviar resumo no WhatsApp
          </a>
        )}
      </section>

      <div className="flex items-center gap-2 rounded-2xl border border-slate-800 bg-[#111B30] p-2">
        <Button variant="ghost" size="icon-lg" disabled={!r} onClick={() => r && setRef(shiftDate(r.week_start, -7))} data-testid="report-week-prev" aria-label="Semana anterior">
          <ChevronLeft />
        </Button>
        <div className="flex-1 text-center">
          <div className="font-mono font-semibold text-sm sm:text-base" data-testid="report-week-label">
            {r ? shortRange(r.week_start, r.week_end) : "—"}
          </div>
          {r && (
            <div className="text-[11px] text-slate-400">
              {r.is_current ? "Semana atual" : (
                <button className="text-sky-300 hover:underline" onClick={() => setRef(null)} data-testid="report-week-current">Voltar para semana atual</button>
              )}
            </div>
          )}
        </div>
        <Button variant="ghost" size="icon-lg" disabled={!r} onClick={() => r && setRef(shiftDate(r.week_start, 7))} data-testid="report-week-next" aria-label="Próxima semana">
          <ChevronRight />
        </Button>
      </div>

      {isLoading && <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{[0, 1, 2, 3].map((i) => <div key={i} className="h-28 rounded-2xl bg-slate-800/40 animate-pulse" />)}</div>}
      {isError && <p className="text-sm text-slate-400" data-testid="report-error">Não foi possível carregar o relatório agora.</p>}

      {r && (
        <>
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {stats.map((s, i) => (
              <div key={s.key} className={cn("rounded-2xl border p-4 animate-rise", s.cls)} style={{ animationDelay: `${i * 50}ms` }} data-testid={`report-stat-${s.key}`}>
                <div className="flex items-center gap-2 text-xs opacity-90"><s.icon className="size-4" /> {s.label}</div>
                <div className="mt-2 font-mono text-xl sm:text-2xl font-semibold tracking-tight" data-testid={`report-stat-${s.key}-value`}>{s.value}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{s.sub}</div>
              </div>
            ))}
          </section>

          <div className="flex flex-wrap gap-2 text-xs">
            {diff !== null && (
              <span className={cn("rounded-full px-3 py-1 border", diff >= 0 ? "border-emerald-600/40 text-emerald-300 bg-emerald-600/10" : "border-red-600/40 text-red-300 bg-red-600/10")} data-testid="report-diff-last-week">
                {diff >= 0 ? "▲" : "▼"} {Math.abs(diff).toFixed(0)}% vs semana anterior
              </span>
            )}
            <span className="rounded-full px-3 py-1 border border-slate-700 text-slate-300" data-testid="report-avg-prev">
              Média das 7 semanas anteriores: <span className="font-mono">{brl(prevAvg)}</span>
            </span>
            <span className="rounded-full px-3 py-1 border border-slate-700 text-slate-300">{r.agendados} agendado(s) · {r.cancelados} cancelado(s)</span>
          </div>

          <section className="grid lg:grid-cols-5 gap-4">
            <div className="lg:col-span-3 rounded-2xl border border-slate-800 bg-[#111B30] p-4 sm:p-5" data-testid="report-daily-chart">
              <h2 className="font-heading font-semibold text-lg">Faturamento por dia</h2>
              <p className="text-xs text-slate-400">Somente serviços concluídos</p>
              <div className="h-64 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={r.days} margin={{ left: -10, right: 4 }}>
                    <CartesianGrid stroke="#1E293B" vertical={false} />
                    <XAxis dataKey="label" stroke="#64748B" tickLine={false} axisLine={false} fontSize={12} />
                    <YAxis stroke="#64748B" tickLine={false} axisLine={false} fontSize={11} tickFormatter={(v: number) => `R$${v}`} />
                    <Tooltip cursor={{ fill: "rgba(56,189,248,0.06)" }} contentStyle={tooltipStyle} formatter={(value: number) => [brl(value), "Faturado"]} />
                    <Bar dataKey="faturado" radius={[6, 6, 0, 0]}>
                      {r.days.map((d) => (
                        <Cell key={d.date} fill={d.faturado > 0 ? "#38BDF8" : "#1E293B"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="lg:col-span-2 rounded-2xl border border-slate-800 bg-[#111B30] p-4 sm:p-5" data-testid="report-payment-methods">
              <h2 className="font-heading font-semibold text-lg">Formas de pagamento</h2>
              <p className="text-xs text-slate-400">Concluídos na semana</p>
              <div className="mt-4 space-y-3">
                {r.payment_methods.length === 0 && <p className="text-sm text-slate-500">Nenhum serviço concluído nesta semana.</p>}
                {r.payment_methods.map((m) => (
                  <div key={m.method}>
                    <div className="flex justify-between text-sm">
                      <span>{m.method} <span className="text-slate-500 text-xs">({m.count})</span></span>
                      <span className="font-mono">{brl(m.total)}</span>
                    </div>
                    <div className="mt-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-emerald-400 transition-[width] duration-500" style={{ width: `${r.faturado ? (m.total / r.faturado) * 100 : 0}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-[#111B30] p-4 sm:p-5" data-testid="report-history">
            <h2 className="font-heading font-semibold text-lg">Comparação: últimas 8 semanas</h2>
            <p className="text-xs text-slate-400">A barra destacada é a semana selecionada</p>
            <div className="h-56 mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={r.history.map((w) => ({ ...w, label: fmtDate(w.week_start, "dd/MM") }))} margin={{ left: -10, right: 4 }}>
                  <CartesianGrid stroke="#1E293B" vertical={false} />
                  <XAxis dataKey="label" stroke="#64748B" tickLine={false} axisLine={false} fontSize={11} />
                  <YAxis stroke="#64748B" tickLine={false} axisLine={false} fontSize={11} tickFormatter={(v: number) => `R$${v}`} />
                  <Tooltip cursor={{ fill: "rgba(56,189,248,0.06)" }} contentStyle={tooltipStyle} formatter={(value: number) => [brl(value), "Faturado"]} labelFormatter={(label: string) => `Semana de ${label}`} />
                  <Bar dataKey="faturado" radius={[6, 6, 0, 0]}>
                    {r.history.map((w) => (
                      <Cell key={w.week_start} fill={w.week_start === r.week_start ? "#10B981" : "#0369A1"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-slate-400 border-b border-slate-800">
                    <th className="py-2 font-medium">Semana</th>
                    <th className="py-2 font-medium text-right">Serviços</th>
                    <th className="py-2 font-medium text-right">Faturado</th>
                    <th className="py-2 font-medium text-right">Recebido</th>
                  </tr>
                </thead>
                <tbody>
                  {[...r.history].reverse().map((w) => (
                    <tr
                      key={w.week_start}
                      onClick={() => setRef(w.week_start)}
                      className={cn("border-b border-slate-800/60 cursor-pointer transition-colors duration-150 hover:bg-white/5", w.week_start === r.week_start && "text-emerald-300")}
                      data-testid={`report-history-row-${w.week_start}`}
                    >
                      <td className="py-2.5 font-mono text-xs sm:text-sm">{shortRange(w.week_start, w.week_end)}</td>
                      <td className="py-2.5 pl-3 text-right font-mono">{w.count}</td>
                      <td className="py-2.5 pl-3 text-right font-mono whitespace-nowrap">{brl(w.faturado)}</td>
                      <td className="py-2.5 pl-3 text-right font-mono whitespace-nowrap">{brl(w.recebido)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </div>
  );
}
