import { useMemo, useState } from "react";
import { AlertTriangle, CalendarCheck, CalendarPlus, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import AppointmentCard from "@/components/AppointmentCard";
import { useAppointmentForm } from "@/lib/form-context";
import { useAppointments, useToday, useWeeklyReport } from "@/lib/queries";
import { brl, dayHeading, fmtDate, shiftDate } from "@/lib/format";
import type { Appointment } from "@/lib/types";
import { cn } from "@/lib/utils";

type View = "hoje" | "semana" | "todos";
const VIEWS: { key: View; label: string }[] = [
  { key: "hoje", label: "Hoje" },
  { key: "semana", label: "Próximos 7 dias" },
  { key: "todos", label: "Todos futuros" },
];

function groupByDate(list: Appointment[]) {
  const map = new Map<string, Appointment[]>();
  list.forEach((a) => map.set(a.date, [...(map.get(a.date) ?? []), a]));
  return [...map.entries()];
}

export default function Agenda() {
  const today = useToday();
  const { openForm } = useAppointmentForm();
  const [view, setView] = useState<View>("hoje");
  const upcoming = useAppointments({ from: today });
  const overdue = useAppointments({ to: shiftDate(today, -1), status: "agendado" });
  const report = useWeeklyReport(null);

  const items = useMemo(() => {
    const list = (!upcoming.isError && upcoming.data) || [];
    if (view === "hoje") return list.filter((a) => a.date === today);
    if (view === "semana") return list.filter((a) => a.date <= shiftDate(today, 6));
    return list;
  }, [upcoming.data, upcoming.isError, view, today]);

  const todayList = ((!upcoming.isError && upcoming.data) || []).filter((a) => a.date === today && a.status !== "cancelado");
  const todayTotal = todayList.reduce((s, a) => s + a.price, 0);
  const overdueList = (!overdue.isError && overdue.data) || [];
  const rep = !report.isError ? report.data : undefined;

  const rawHeading = fmtDate(today, "EEEE, d 'de' MMMM");
  const heading = rawHeading.charAt(0).toUpperCase() + rawHeading.slice(1);

  return (
    <div className="space-y-6">
      <section className="animate-rise">
        <p className="text-sm text-sky-300/80" data-testid="agenda-today-label">{heading}</p>
        <h1 className="font-heading text-3xl sm:text-4xl font-bold tracking-tight mt-1">Sua agenda</h1>
      </section>

      <section className="grid grid-cols-2 lg:grid-cols-3 gap-3 animate-rise" style={{ animationDelay: "60ms" }}>
        <div className="rounded-2xl border border-sky-800/50 bg-[#0F2444] p-4">
          <div className="flex items-center gap-2 text-xs text-sky-300"><CalendarCheck className="size-4" /> Serviços hoje</div>
          <div className="mt-2 font-mono text-2xl font-semibold" data-testid="stat-today-count">{todayList.length}</div>
          <div className="text-xs text-slate-400 mt-0.5">Total previsto <span className="font-mono text-slate-200">{brl(todayTotal)}</span></div>
        </div>
        <div className="rounded-2xl border border-emerald-800/40 bg-[#092E2B] p-4">
          <div className="flex items-center gap-2 text-xs text-emerald-300"><Wallet className="size-4" /> Faturado na semana</div>
          <div className="mt-2 font-mono text-2xl font-semibold text-emerald-300" data-testid="stat-week-revenue">{brl(rep?.faturado ?? 0)}</div>
          <div className="text-xs text-emerald-200/60 mt-0.5">{rep?.servicos_concluidos ?? 0} concluídos</div>
        </div>
        <div className="col-span-2 lg:col-span-1 rounded-2xl border border-amber-800/40 bg-[#2A1F0D] p-4">
          <div className="flex items-center gap-2 text-xs text-amber-300"><Wallet className="size-4" /> A receber na semana</div>
          <div className="mt-2 font-mono text-2xl font-semibold text-amber-300" data-testid="stat-week-pending">{brl(rep?.a_receber ?? 0)}</div>
          <div className="text-xs text-amber-200/60 mt-0.5">{rep?.agendados ?? 0} ainda agendados</div>
        </div>
      </section>

      {overdueList.length > 0 && (
        <section className="rounded-2xl border border-amber-700/50 bg-amber-950/30 p-4 space-y-3" data-testid="overdue-section">
          <div className="flex items-center gap-2 text-amber-300 font-semibold text-sm">
            <AlertTriangle className="size-4" />
            {overdueList.length} serviço(s) de dias anteriores ainda como "Agendado" — atualize o status
          </div>
          <div className="space-y-3">
            {overdueList.map((a) => (
              <AppointmentCard key={a.id} appt={a} showDate />
            ))}
          </div>
        </section>
      )}

      <div className="flex gap-1 rounded-xl bg-slate-900/70 p-1 border border-slate-800 w-full sm:w-fit overflow-x-auto" role="tablist">
        {VIEWS.map((v) => (
          <button
            key={v.key}
            role="tab"
            aria-selected={view === v.key}
            onClick={() => setView(v.key)}
            data-testid={`agenda-view-${v.key}`}
            className={cn(
              "flex-1 sm:flex-none whitespace-nowrap h-9 px-4 rounded-lg text-sm font-medium transition-colors duration-150",
              view === v.key ? "bg-sky-600 text-white" : "text-slate-400 hover:text-slate-100",
            )}
          >
            {v.label}
          </button>
        ))}
      </div>

      <section className="space-y-6" data-testid="agenda-list">
        {upcoming.isLoading && <div className="space-y-3">{[0, 1].map((i) => <div key={i} className="h-36 rounded-2xl bg-slate-800/40 animate-pulse" />)}</div>}
        {!upcoming.isLoading && items.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-700 p-10 text-center" data-testid="agenda-empty">
            <CalendarPlus className="size-10 mx-auto text-sky-400/70" />
            <p className="mt-3 font-heading text-lg font-semibold">Nenhum serviço {view === "hoje" ? "para hoje" : "neste período"}</p>
            <p className="text-sm text-slate-400 mt-1">Cadastre um novo atendimento para não esquecer.</p>
            <Button className="mt-4 h-11" onClick={() => openForm()} data-testid="agenda-empty-new-btn">Novo agendamento</Button>
          </div>
        )}
        {groupByDate(items).map(([date, list]) => (
          <div key={date} className="space-y-3">
            <div className="flex items-baseline gap-3">
              <h2 className={cn("font-heading text-lg font-semibold", date === today && "text-sky-300")} data-testid={`agenda-day-${date}`}>
                {dayHeading(date, today)}
              </h2>
              <span className="text-xs text-slate-500">{fmtDate(date, "dd/MM")} · {list.length} serviço(s)</span>
            </div>
            {list.map((a, i) => (
              <div key={a.id} className="animate-rise" style={{ animationDelay: `${i * 50}ms` }}>
                <AppointmentCard appt={a} highlight={date === today && a.status === "agendado"} />
              </div>
            ))}
          </div>
        ))}
      </section>
    </div>
  );
}
