import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import AppointmentCard from "@/components/AppointmentCard";
import { useAppointments } from "@/lib/queries";
import { STATUS_LABELS, type Status } from "@/lib/types";
import { cn } from "@/lib/utils";

type Filter = "todos" | Status | "nao_pago";
const FILTERS: { key: Filter; label: string }[] = [
  { key: "todos", label: "Todos" },
  { key: "agendado", label: STATUS_LABELS.agendado },
  { key: "concluido", label: STATUS_LABELS.concluido },
  { key: "cancelado", label: STATUS_LABELS.cancelado },
  { key: "nao_pago", label: "Concluídos a receber" },
];

export default function History() {
  const { data, isLoading, isError } = useAppointments({});
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("todos");

  const items = useMemo(() => {
    const term = q.trim().toLowerCase();
    return [...((!isError && data) || [])]
      .reverse()
      .filter((a) => {
        if (filter === "nao_pago") return a.status === "concluido" && !a.is_paid;
        return filter === "todos" || a.status === filter;
      })
      .filter((a) => !term || [a.client_name, a.address, a.client_phone, a.service_type].some((v) => v.toLowerCase().includes(term)));
  }, [data, isError, q, filter]);

  return (
    <div className="space-y-6">
      <section className="animate-rise">
        <p className="text-sm text-sky-300/80">Todos os atendimentos registrados</p>
        <h1 className="font-heading text-3xl sm:text-4xl font-bold tracking-tight mt-1">Histórico</h1>
      </section>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-500" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por cliente, endereço, telefone ou serviço" className="h-11 pl-9" data-testid="history-search-input" />
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            data-testid={`history-filter-${f.key}`}
            className={cn(
              "whitespace-nowrap h-9 px-3.5 rounded-full text-sm border transition-colors duration-150",
              filter === f.key ? "bg-sky-600 border-sky-600 text-white" : "border-slate-700 text-slate-300 hover:border-slate-500",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <p className="text-xs text-slate-500" data-testid="history-count">{items.length} resultado(s)</p>

      <section className="space-y-3" data-testid="history-list">
        {isLoading && [0, 1, 2].map((i) => <div key={i} className="h-36 rounded-2xl bg-slate-800/40 animate-pulse" />)}
        {!isLoading && items.length === 0 && (
          <p className="rounded-2xl border border-dashed border-slate-700 p-8 text-center text-slate-400" data-testid="history-empty">Nenhum atendimento encontrado.</p>
        )}
        {items.map((a) => (
          <AppointmentCard key={a.id} appt={a} showDate />
        ))}
      </section>
    </div>
  );
}
