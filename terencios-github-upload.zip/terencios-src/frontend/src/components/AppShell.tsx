import { useEffect, useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { BarChart3, CalendarDays, History, Plus, Snowflake } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import AppointmentForm from "@/components/AppointmentForm";
import { FormContext } from "@/lib/form-context";
import { useWeeklyReport } from "@/lib/queries";
import { brl } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { Appointment } from "@/lib/types";

const NAV = [
  { to: "/", label: "Agenda", icon: CalendarDays, testid: "btn-nav-agenda" },
  { to: "/relatorio", label: "Relatório", icon: BarChart3, testid: "btn-nav-report" },
  { to: "/historico", label: "Histórico", icon: History, testid: "btn-nav-history" },
];

export default function AppShell() {
  const [open, setOpen] = useState(false);
  const [online, setOnline] = useState(navigator.onLine);
  const [editing, setEditing] = useState<Appointment | undefined>();
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => { window.removeEventListener("online", update); window.removeEventListener("offline", update); };
  }, []);
  const report = useWeeklyReport(null);

  const openForm = (appt?: Appointment) => {
    setEditing(appt);
    setOpen(true);
  };

  return (
    <FormContext.Provider value={{ openForm }}>
      <div className="min-h-screen">
        <header className="sticky top-0 z-40 h-16 backdrop-blur-xl bg-[#0B1120]/90 border-b border-sky-950/60 shadow-lg">
          <div className="max-w-5xl mx-auto h-full px-4 sm:px-6 flex items-center gap-4">
            <NavLink to="/" className="flex items-center gap-2.5 shrink-0" data-testid="header-brand-title">
              <span className="grid place-items-center size-9 rounded-xl bg-gradient-to-br from-sky-500 to-sky-700 shadow-[0_0_20px_rgba(14,165,233,0.35)]">
                <Snowflake className="size-5 text-white" />
              </span>
              <span className="leading-tight">
                <span className="block font-heading font-bold text-[15px] sm:text-[17px] tracking-tight whitespace-nowrap">Terencios Refrigeração</span>
                <span className="block text-[11px] text-sky-300/80 -mt-0.5">Agenda de serviços</span>
              </span>
            </NavLink>

            <nav className="hidden md:flex items-center gap-1 ml-4">
              {NAV.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  end
                  data-testid={`${n.testid}-desktop`}
                  className={({ isActive }) =>
                    cn(
                      "px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-150",
                      isActive ? "bg-sky-500/15 text-sky-300" : "text-slate-400 hover:text-slate-100 hover:bg-white/5",
                    )
                  }
                >
                  {n.label}
                </NavLink>
              ))}
            </nav>

            <div className="ml-auto flex items-center gap-3">
              {report.data && !report.isError && (
                <span
                  className="hidden sm:inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs text-emerald-300"
                  data-testid="header-week-revenue"
                >
                  Semana: <span className="font-mono font-semibold">{brl(report.data.faturado)}</span>
                </span>
              )}
              <Button
                onClick={() => openForm()}
                className="hidden md:inline-flex h-10 px-4 active:scale-[0.98] transition-transform duration-100"
                data-testid="btn-new-appointment"
              >
                <Plus className="size-4" /> Novo serviço
              </Button>
            </div>
          </div>
        </header>

        {!online && <div role="status" className="mx-auto max-w-5xl px-4 sm:px-6 pt-3"><div className="rounded-xl border border-amber-700/50 bg-amber-950/40 px-3 py-2 text-xs text-amber-200">Sem internet — modo offline ativo. Seus cadastros ficam salvos neste aparelho e serão sincronizados quando a conexão voltar.</div></div>}
        <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-28 md:pb-12">
          <Outlet />
        </main>

        {/* Mobile bottom bar */}
        <nav className="md:hidden fixed bottom-0 inset-x-0 z-50 backdrop-blur-2xl bg-[#0B1120]/95 border-t border-slate-800 shadow-[0_-4px_24px_rgba(0,0,0,0.5)] pb-[env(safe-area-inset-bottom)]">
          <div className="grid grid-cols-4 h-16">
            {NAV.slice(0, 1).map((n) => (
              <MobileTab key={n.to} {...n} />
            ))}
            <button
              onClick={() => openForm()}
              className="flex flex-col items-center justify-center gap-0.5 text-sky-300"
              data-testid="btn-new-appointment-mobile"
            >
              <span className="grid place-items-center size-10 -mt-5 rounded-2xl bg-sky-600 text-white shadow-[0_6px_20px_rgba(2,132,199,0.5)] active:scale-95 transition-transform duration-100">
                <Plus className="size-5" />
              </span>
              <span className="text-[11px] font-medium">Novo</span>
            </button>
            {NAV.slice(1).map((n) => (
              <MobileTab key={n.to} {...n} />
            ))}
          </div>
        </nav>

        <AppointmentForm open={open} onOpenChange={setOpen} appointment={editing} />
        <Toaster richColors theme="dark" />
      </div>
    </FormContext.Provider>
  );
}

function MobileTab({ to, label, icon: Icon, testid }: (typeof NAV)[number]) {
  return (
    <NavLink
      to={to}
      end
      data-testid={testid}
      className={({ isActive }) =>
        cn(
          "flex flex-col items-center justify-center gap-1 text-[11px] font-medium transition-colors duration-150",
          isActive ? "text-sky-300" : "text-slate-500",
        )
      }
    >
      <Icon className="size-5" />
      {label}
    </NavLink>
  );
}
