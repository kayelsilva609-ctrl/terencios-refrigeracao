import { useState } from "react";
import { toast } from "sonner";
import { ChevronDown, Clock, MapPin, MessageCircle, Pencil, Phone, Trash2, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useDeleteAppointment, usePatchAppointment } from "@/lib/queries";
import { useAppointmentForm } from "@/lib/form-context";
import { brl, fmtDate, mapsLink, phoneDigits, waLink } from "@/lib/format";
import { STATUS_LABELS, type Appointment, type Status } from "@/lib/types";
import { cn } from "@/lib/utils";

const STATUS_STYLE: Record<Status, string> = {
  agendado: "bg-sky-700 text-white",
  concluido: "bg-emerald-700 text-white",
  cancelado: "bg-red-800 text-white",
};

interface Props {
  appt: Appointment;
  highlight?: boolean;
  showDate?: boolean;
}

export default function AppointmentCard({ appt, highlight, showDate }: Props) {
  const { openForm } = useAppointmentForm();
  const patch = usePatchAppointment();
  const del = useDeleteAppointment();
  const [confirm, setConfirm] = useState(false);
  const [pulse, setPulse] = useState(false);
  const id = appt.id;
  const canceled = appt.status === "cancelado";

  const update = (data: Partial<Appointment>, msg: string) =>
    patch.mutate(
      { id, data },
      {
        onSuccess: () => {
          toast.success(msg);
          setPulse(true);
          setTimeout(() => setPulse(false), 650);
        },
        onError: () => toast.error("Falha ao atualizar"),
      },
    );

  const waText = `Olá ${appt.client_name}! Confirmando o serviço de ${appt.service_type.toLowerCase()} no dia ${fmtDate(appt.date, "dd/MM")} às ${appt.time}.`;
  const hasPhone = phoneDigits(appt.client_phone).length > 0;

  return (
    <article
      data-testid={`appointment-card-${id}`}
      className={cn(
        "group relative rounded-2xl border p-4 sm:p-5 transition-[transform,border-color,background-color] duration-150 hover:-translate-y-0.5",
        highlight
          ? "bg-[#0F2444] border-sky-600/50 shadow-[0_0_0_1px_rgba(2,132,199,0.25),0_10px_30px_-10px_rgba(2,132,199,0.45)]"
          : "bg-[#111B30] border-slate-800 hover:border-slate-700 hover:bg-[#162340]",
        canceled && "opacity-60",
        pulse && "animate-glow",
      )}
    >
      <div className="flex items-start gap-4">
        <div className="shrink-0 text-center w-14">
          <div className="flex items-center justify-center gap-1 text-sky-300">
            <Clock className="size-3.5" />
          </div>
          <div className="font-mono text-lg font-semibold tracking-tight" data-testid={`appointment-time-${id}`}>{appt.time}</div>
          {showDate && <div className="text-[11px] text-slate-400 capitalize">{fmtDate(appt.date, "EEE dd/MM")}</div>}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className={cn("font-heading text-base sm:text-lg font-semibold truncate", canceled && "line-through")} data-testid={`appointment-client-${id}`}>
              {appt.client_name}
            </h3>
            <span className="inline-flex items-center gap-1 rounded-md bg-slate-800/80 px-2 py-0.5 text-[11px] text-slate-300" data-testid={`appointment-service-${id}`}>
              <Wrench className="size-3" /> {appt.service_type}
            </span>
          </div>
          {appt.equipment && <p className="text-xs text-slate-400 mt-0.5">{appt.equipment}</p>}
          {appt.address && (
            <p className="mt-1.5 text-sm text-slate-300 flex items-start gap-1.5">
              <MapPin className="size-3.5 mt-0.5 shrink-0 text-slate-500" />
              <span className="line-clamp-2">{appt.address}</span>
            </p>
          )}
          {appt.notes && <p className="mt-1.5 text-xs text-slate-400 italic line-clamp-2">“{appt.notes}”</p>}
        </div>

        <div className="shrink-0 text-right">
          <div className="font-mono text-lg sm:text-xl font-semibold tracking-tight text-slate-50" data-testid={`appointment-price-${id}`}>
            {brl(appt.price)}
          </div>
          <div className="text-[11px] text-slate-500">{appt.payment_method}</div>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger
            data-testid={`appointment-status-${id}`}
            className={cn(
              "inline-flex h-9 items-center gap-1 rounded-lg px-3 text-[11px] font-bold uppercase tracking-wider transition-[filter] duration-150 hover:brightness-110",
              STATUS_STYLE[appt.status],
            )}
          >
            {STATUS_LABELS[appt.status]} <ChevronDown className="size-3.5" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            {(Object.keys(STATUS_LABELS) as Status[]).map((s) => (
              <DropdownMenuItem
                key={s}
                data-testid={`appointment-status-option-${s}-${id}`}
                onClick={() => s !== appt.status && update({ status: s }, `Marcado como ${STATUS_LABELS[s]}`)}
              >
                {STATUS_LABELS[s]}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <button
          data-testid={`appointment-paid-toggle-${id}`}
          onClick={() => update({ is_paid: !appt.is_paid }, appt.is_paid ? "Marcado como a receber" : "Pagamento recebido")}
          className={cn(
            "inline-flex h-9 items-center rounded-lg px-3 text-[11px] font-bold uppercase tracking-wider transition-[filter,transform] duration-150 hover:brightness-110 active:scale-[0.97]",
            appt.is_paid ? "bg-emerald-900 text-emerald-100 ring-1 ring-emerald-600/50" : "bg-amber-900/80 text-amber-100 ring-1 ring-amber-600/50",
          )}
        >
          {appt.is_paid ? "Pago" : "A receber"}
        </button>

        <div className="ml-auto flex items-center gap-1">
          {hasPhone && (
            <>
              <a href={waLink(appt.client_phone, waText)} target="_blank" rel="noreferrer" aria-label="WhatsApp" data-testid={`appointment-btn-whatsapp-${id}`} className="grid place-items-center size-10 rounded-lg text-emerald-400 hover:bg-emerald-500/10 transition-colors duration-150">
                <MessageCircle className="size-4.5" />
              </a>
              <a href={`tel:${phoneDigits(appt.client_phone)}`} aria-label="Ligar" data-testid={`appointment-btn-call-${id}`} className="grid place-items-center size-10 rounded-lg text-sky-300 hover:bg-sky-500/10 transition-colors duration-150">
                <Phone className="size-4.5" />
              </a>
            </>
          )}
          {appt.address && (
            <a href={mapsLink(appt.address)} target="_blank" rel="noreferrer" aria-label="Abrir no mapa" data-testid={`appointment-btn-maps-${id}`} className="grid place-items-center size-10 rounded-lg text-sky-300 hover:bg-sky-500/10 transition-colors duration-150">
              <MapPin className="size-4.5" />
            </a>
          )}
          <button onClick={() => openForm(appt)} aria-label="Editar" data-testid={`appointment-btn-edit-${id}`} className="grid place-items-center size-10 rounded-lg text-slate-300 hover:bg-white/5 transition-colors duration-150">
            <Pencil className="size-4" />
          </button>
          <button onClick={() => setConfirm(true)} aria-label="Excluir" data-testid={`appointment-btn-delete-${id}`} className="grid place-items-center size-10 rounded-lg text-red-400 hover:bg-red-500/10 transition-colors duration-150">
            <Trash2 className="size-4" />
          </button>
        </div>
      </div>

      <Dialog open={confirm} onOpenChange={setConfirm}>
        <DialogContent className="bg-[#0F182B] border-slate-800">
          <DialogHeader>
            <DialogTitle>Excluir agendamento?</DialogTitle>
            <DialogDescription>
              O serviço de {appt.client_name} em {fmtDate(appt.date, "dd/MM")} às {appt.time} será removido permanentemente.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(false)} data-testid={`delete-cancel-${id}`}>Cancelar</Button>
            <Button
              variant="destructive"
              data-testid={`delete-confirm-${id}`}
              disabled={del.isPending}
              onClick={() =>
                del.mutate(id, {
                  onSuccess: () => {
                    toast.success("Agendamento excluído");
                    setConfirm(false);
                  },
                  onError: () => toast.error("Falha ao excluir"),
                })
              }
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </article>
  );
}
