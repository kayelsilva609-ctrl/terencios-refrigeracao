import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSaveAppointment, useToday } from "@/lib/queries";
import { parsePrice } from "@/lib/format";
import { PAYMENT_METHODS, SERVICE_TYPES, STATUS_LABELS, type Appointment, type Status } from "@/lib/types";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  appointment?: Appointment;
}

interface FormState {
  client_name: string;
  client_phone: string;
  address: string;
  service_type: string;
  equipment: string;
  date: string;
  time: string;
  price: string;
  payment_method: string;
  is_paid: boolean;
  status: Status;
  notes: string;
}

const empty = (today: string): FormState => ({
  client_name: "",
  client_phone: "",
  address: "",
  service_type: SERVICE_TYPES[0],
  equipment: "",
  date: today,
  time: "09:00",
  price: "",
  payment_method: "Pix",
  is_paid: false,
  status: "agendado",
  notes: "",
});

const fromAppt = (a: Appointment): FormState => ({
  ...a,
  price: a.price.toFixed(2).replace(".", ","),
});

export default function AppointmentForm({ open, onOpenChange, appointment }: Props) {
  const today = useToday();
  const save = useSaveAppointment();
  const [f, setF] = useState<FormState>(() => empty(today));

  useEffect(() => {
    if (open) setF(appointment ? fromAppt(appointment) : empty(today));
  }, [open, appointment, today]);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setF((p) => ({ ...p, [k]: v }));

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const price = parsePrice(f.price);
    if (!f.client_name.trim()) return toast.error("Informe o nome do cliente");
    if (!f.date || !f.time) return toast.error("Informe data e horário");
    if (Number.isNaN(price) || price < 0) return toast.error("Valor inválido");
    save.mutate(
      { id: appointment?.id, data: { ...f, client_name: f.client_name.trim(), price } },
      {
        onSuccess: () => {
          toast.success(appointment ? "Agendamento atualizado" : "Agendamento criado");
          onOpenChange(false);
        },
        onError: () => toast.error("Não foi possível salvar. Tente novamente."),
      },
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl max-h-[92vh] overflow-y-auto bg-[#0F182B] border-slate-800" data-testid="appointment-form-dialog">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl">{appointment ? "Editar agendamento" : "Novo agendamento"}</DialogTitle>
          <DialogDescription>Preencha os dados do serviço. Campos com * são obrigatórios.</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="grid gap-4" data-testid="appointment-form">
          <div className="grid gap-1.5">
            <Label htmlFor="client_name">Nome do cliente *</Label>
            <Input id="client_name" className="h-11" value={f.client_name} onChange={(e) => set("client_name", e.target.value)} placeholder="Ex: Maria Silva / Padaria Central" data-testid="form-input-client-name" />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="client_phone">WhatsApp / Telefone</Label>
              <Input id="client_phone" type="tel" className="h-11" value={f.client_phone} onChange={(e) => set("client_phone", e.target.value)} placeholder="(11) 98765-4321" data-testid="form-input-client-phone" />
            </div>
            <div className="grid gap-1.5">
              <Label>Tipo de serviço *</Label>
              <Select value={f.service_type} onValueChange={(v: string) => set("service_type", v)}>
                <SelectTrigger className="h-11 w-full" data-testid="form-select-service-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SERVICE_TYPES.map((s) => (
                    <SelectItem key={s} value={s} data-testid={`form-service-option-${s}`}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="address">Endereço</Label>
            <Input id="address" className="h-11" value={f.address} onChange={(e) => set("address", e.target.value)} placeholder="Rua das Palmeiras, 120 - Apto 42" data-testid="form-input-address" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="equipment">Aparelho / BTUs (opcional)</Label>
            <Input id="equipment" className="h-11" value={f.equipment} onChange={(e) => set("equipment", e.target.value)} placeholder="Ex: Split Inverter 12.000 BTUs" data-testid="form-input-equipment" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="date">Data *</Label>
              <Input id="date" type="date" className="h-11" value={f.date} onChange={(e) => set("date", e.target.value)} data-testid="form-input-date" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="time">Horário *</Label>
              <Input id="time" type="time" className="h-11" value={f.time} onChange={(e) => set("time", e.target.value)} data-testid="form-input-time" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="price">Valor (R$) *</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">R$</span>
                <Input id="price" inputMode="decimal" className="h-11 pl-10 font-mono" value={f.price} onChange={(e) => set("price", e.target.value)} placeholder="0,00" data-testid="form-input-price" />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Pagamento</Label>
              <Select value={f.payment_method} onValueChange={(v: string) => set("payment_method", v)}>
                <SelectTrigger className="h-11 w-full" data-testid="form-select-payment-method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label>Status do serviço</Label>
              <div className="grid grid-cols-3 gap-1 rounded-xl bg-slate-900/70 p-1 border border-slate-800">
                {(Object.keys(STATUS_LABELS) as Status[]).map((s) => (
                  <button
                    type="button"
                    key={s}
                    onClick={() => set("status", s)}
                    data-testid={`form-status-${s}`}
                    className={cn(
                      "h-9 rounded-lg text-xs font-semibold transition-colors duration-150",
                      f.status === s
                        ? s === "concluido" ? "bg-emerald-700 text-white" : s === "cancelado" ? "bg-red-800 text-white" : "bg-sky-700 text-white"
                        : "text-slate-400 hover:text-slate-100",
                    )}
                  >
                    {STATUS_LABELS[s]}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Pagamento recebido?</Label>
              <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-900/70 p-1 border border-slate-800">
                {[false, true].map((v) => (
                  <button
                    type="button"
                    key={String(v)}
                    onClick={() => set("is_paid", v)}
                    data-testid={`form-paid-${v ? "yes" : "no"}`}
                    className={cn(
                      "h-9 rounded-lg text-xs font-semibold transition-colors duration-150",
                      f.is_paid === v ? (v ? "bg-emerald-700 text-white" : "bg-amber-800 text-amber-50") : "text-slate-400 hover:text-slate-100",
                    )}
                  >
                    {v ? "Pago" : "A receber"}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="notes">Observações</Label>
            <Textarea id="notes" rows={3} value={f.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Ex: levar escada, gás R410A, portaria pede documento" data-testid="form-input-notes" />
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button type="button" variant="outline" className="h-11" onClick={() => onOpenChange(false)} data-testid="form-cancel-btn">
              Cancelar
            </Button>
            <Button type="submit" className="h-11 px-6" disabled={save.isPending} data-testid="form-submit-appointment">
              {save.isPending ? "Salvando..." : appointment ? "Salvar alterações" : "Criar agendamento"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
