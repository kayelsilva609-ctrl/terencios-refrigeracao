import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter } from 'react-router-dom'
import './index.css'
import App from './App.tsx'
import { queryClient } from './lib/queryClient'
import { runOfflineSync } from './lib/queries'

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {})
  })
}

window.addEventListener('online', () => { void runOfflineSync(); queryClient.invalidateQueries(); })
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && navigator.onLine) void runOfflineSync(); })
window.addEventListener('load', () => { if (navigator.onLine) void runOfflineSync(); })

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </QueryClientProvider>
  </StrictMode>,
)
