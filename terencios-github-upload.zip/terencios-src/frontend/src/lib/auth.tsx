import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { apiGet, apiPost, hasRemoteApi } from "@/lib/api";
import { beginSession, endSession } from "@/lib/session";

type AuthValue = { username: string | null; loading: boolean; login: (username: string, password: string) => Promise<void>; logout: () => Promise<void> };
const AuthContext = createContext<AuthValue | null>(null);
const CACHE_KEY = "terencios-auth-user";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [username, setUsername] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const cached = localStorage.getItem(CACHE_KEY);
    if (!hasRemoteApi) {
      if (active) { setUsername(cached); setLoading(false); }
      return () => { active = false; };
    }
    apiGet<{ username: string }>("/auth/me").then((user) => {
      if (!active) return;
      localStorage.setItem(CACHE_KEY, user.username);
      setUsername(user.username);
    }).catch((error: unknown) => {
      if (!active) return;
      const status = (error as { status?: number } | null)?.status;
      // A previously authenticated user can still use the locally cached agenda offline.
      if (cached && status !== 401) setUsername(cached);
      else if (status === 401) localStorage.removeItem(CACHE_KEY);
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const value = useMemo<AuthValue>(() => ({
    username, loading,
    login: async (user, password) => {
      if (!hasRemoteApi) throw new Error("O servidor compartilhado ainda não foi configurado. É necessário publicar o servidor antes de entrar.");
      const result = await apiPost<{ username: string }>("/auth/login", { username: user, password });
      beginSession();
      localStorage.setItem(CACHE_KEY, result.username);
      setUsername(result.username);
    },
    logout: async () => {
      localStorage.removeItem(CACHE_KEY);
      setUsername(null);
      await endSession("/login");
    },
  }), [username, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error("useAuth precisa estar dentro de AuthProvider");
  return value;
}
