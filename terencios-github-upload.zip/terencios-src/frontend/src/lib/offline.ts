import type { Appointment, AppointmentCreate, AppointmentPatch, WeeklyReport } from '@/lib/types';

const DB_NAME = 'terencios-offline-v1';
const STORE = 'data';
const APPOINTMENTS = 'appointments';
const OUTBOX = 'outbox';

type Pending = { key: string; kind: 'create' | 'update' | 'delete'; id: string; data?: AppointmentCreate | AppointmentPatch; createdAt: number };

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function store<T>(key: string, mode: IDBTransactionMode, action: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const req = action(tx.objectStore(STORE));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    tx.oncomplete = () => db.close();
    tx.onerror = () => reject(tx.error);
  });
}

const get = <T>(key: string) => store<T | undefined>(key, 'readonly', s => s.get(key));
const put = <T>(key: string, value: T) => store<IDBValidKey>(key, 'readwrite', s => s.put(value, key));

export async function localAppointments(): Promise<Appointment[]> {
  return (await get<Appointment[]>(APPOINTMENTS)) ?? [];
}
async function saveAppointments(items: Appointment[]) { await put(APPOINTMENTS, items); }
export async function cacheAppointments(items: Appointment[]) {
  const current = await localAppointments();
  const map = new Map(current.map(a => [a.id, a]));
  items.forEach(a => map.set(a.id, a));
  await saveAppointments([...map.values()].sort((a,b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time)));
}
async function pending(): Promise<Pending[]> { return (await get<Pending[]>(OUTBOX)) ?? []; }
async function savePending(items: Pending[]) { await put(OUTBOX, items); }

export function filterLocal(items: Appointment[], params: { from?: string; to?: string; status?: string }) {
  return items.filter(a => (!params.from || a.date >= params.from) && (!params.to || a.date <= params.to) && (!params.status || a.status === params.status));
}

export async function offlineCreate(data: AppointmentCreate): Promise<Appointment> {
  const id = `local-${crypto.randomUUID()}`;
  const appt: Appointment = { ...data, id, created_at: new Date().toISOString() };
  await cacheAppointments([appt]);
  const q = await pending(); q.push({ key: crypto.randomUUID(), kind: 'create', id, data, createdAt: Date.now() }); await savePending(q);
  return appt;
}
export async function offlineUpdate(id: string, data: AppointmentCreate | AppointmentPatch): Promise<Appointment> {
  const items = await localAppointments();
  const current = items.find(a => a.id === id);
  if (!current) throw new Error('Agendamento não encontrado no aparelho');
  const updated = { ...current, ...data } as Appointment;
  await saveAppointments(items.map(a => a.id === id ? updated : a));
  const q = await pending();
  const create = q.find(x => x.id === id && x.kind === 'create');
  if (create) create.data = updated;
  else {
    const existing = q.find(x => x.id === id && x.kind === 'update');
    if (existing) existing.data = { ...(existing.data ?? {}), ...data };
    else q.push({ key: crypto.randomUUID(), kind: 'update', id, data, createdAt: Date.now() });
  }
  await savePending(q); return updated;
}
export async function offlineDelete(id: string) {
  await saveAppointments((await localAppointments()).filter(a => a.id !== id));
  const q = await pending();
  const isLocalCreate = q.some(x => x.id === id && x.kind === 'create');
  await savePending(isLocalCreate ? q.filter(x => x.id !== id) : [...q.filter(x => x.id !== id), { key: crypto.randomUUID(), kind: 'delete', id, createdAt: Date.now() }]);
}

let syncing = false;
export async function syncPending(api: { post: <T>(p:string,b?:unknown)=>Promise<T>; put: <T>(p:string,b?:unknown)=>Promise<T>; patch: <T>(p:string,b?:unknown)=>Promise<T>; del: <T>(p:string)=>Promise<T> }) {
  if (syncing || !navigator.onLine) return;
  syncing = true;
  try {
    let queue = await pending();
    for (const item of queue) {
      if (item.kind === 'create') {
        const remote = await api.post<Appointment>('/appointments', item.data);
        const all = await localAppointments();
        await saveAppointments(all.map(a => a.id === item.id ? remote : a));
      } else if (item.kind === 'update') {
        if (item.id.startsWith('local-')) continue;
        const remote = await api.patch<Appointment>(`/appointments/${item.id}`, item.data);
        await cacheAppointments([remote]);
      } else {
        if (!item.id.startsWith('local-')) await api.del<void>(`/appointments/${item.id}`);
        await saveAppointments((await localAppointments()).filter(a => a.id !== item.id));
      }
      queue = queue.filter(x => x.key !== item.key);
      await savePending(queue);
    }
  } finally { syncing = false; }
}

export function localWeeklyReport(items: Appointment[], date: string | null): WeeklyReport {
  const ref = date ? new Date(`${date}T12:00:00`) : new Date();
  const start = new Date(ref); start.setDate(ref.getDate() - ((ref.getDay() + 6) % 7)); start.setHours(12,0,0,0);
  const end = new Date(start); end.setDate(start.getDate() + 6);
  const histStart = new Date(start); histStart.setDate(start.getDate() - 49);
  const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const weekStart = iso(start), weekEnd = iso(end);
  const week = items.filter(a => a.date >= weekStart && a.date <= weekEnd);
  const done = week.filter(a => a.status === 'concluido');
  const faturado = done.reduce((s,a) => s+a.price,0), recebido = done.filter(a=>a.is_paid).reduce((s,a)=>s+a.price,0);
  const labels = ['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'];
  const days = labels.map((label,i) => { const d=new Date(start); d.setDate(start.getDate()+i); const day=iso(d); const list=done.filter(a=>a.date===day); return {date:day,label,faturado:list.reduce((s,a)=>s+a.price,0),count:list.length}; });
  const methods = new Map<string,{method:string;total:number;count:number}>();
  done.forEach(a=>{const m=a.payment_method||'A combinar'; const v=methods.get(m)??{method:m,total:0,count:0};v.total+=a.price;v.count++;methods.set(m,v);});
  const history = Array.from({length:8},(_,i)=>{const ws=new Date(histStart);ws.setDate(histStart.getDate()+7*i);const we=new Date(ws);we.setDate(ws.getDate()+6);const list=items.filter(a=>a.date>=iso(ws)&&a.date<=iso(we)&&a.status==='concluido');return {week_start:iso(ws),week_end:iso(we),faturado:list.reduce((s,a)=>s+a.price,0),recebido:list.filter(a=>a.is_paid).reduce((s,a)=>s+a.price,0),count:list.length};});
  return {week_start:weekStart,week_end:weekEnd,is_current:weekStart===iso(new Date(new Date().setDate(new Date().getDate()-((new Date().getDay()+6)%7)))),faturado,recebido,a_receber:faturado-recebido,servicos_concluidos:done.length,ticket_medio:done.length?faturado/done.length:0,agendados:week.filter(a=>a.status==='agendado').length,cancelados:week.filter(a=>a.status==='cancelado').length,days,payment_methods:[...methods.values()].sort((a,b)=>b.total-a.total),history};
}
