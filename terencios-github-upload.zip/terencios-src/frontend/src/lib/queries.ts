import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiDelete, apiGet, apiPatch, apiPost, apiPut } from "@/lib/api";
import { localToday } from "@/lib/format";
import { cacheAppointments, filterLocal, localAppointments, localWeeklyReport, offlineCreate, offlineDelete, offlineUpdate, syncPending } from "@/lib/offline";
import type { Appointment, AppointmentCreate, AppointmentPatch, TodayInfo, WeeklyReport } from "@/lib/types";

const syncApi = { post: apiPost, put: apiPut, patch: apiPatch, del: apiDelete };
export function runOfflineSync() { return syncPending(syncApi); }
function isNetworkFailure(error: unknown) { return !navigator.onLine || error instanceof TypeError; }

export function useToday(): string {
  const { data, isError } = useQuery({ queryKey: ["today"], queryFn: () => apiGet<TodayInfo>("/today"), staleTime: 5 * 60_000 });
  return !isError && data ? data.today : localToday();
}
export interface ListParams { from?: string; to?: string; status?: string; }
export function useAppointments(params: ListParams, enabled = true) {
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => v && qs.set(k, v));
  return useQuery({
    queryKey: ["appointments", params], enabled,
    queryFn: async () => {
      try { const items = await apiGet<Appointment[]>(`/appointments?${qs.toString()}`); await cacheAppointments(items); return items; }
      catch (error) { if (!isNetworkFailure(error)) throw error; return filterLocal(await localAppointments(), params); }
    },
  });
}
export function useWeeklyReport(date: string | null) {
  return useQuery({
    queryKey: ["report", date],
    queryFn: async () => {
      try { return await apiGet<WeeklyReport>(`/reports/weekly${date ? `?date=${date}` : ""}`); }
      catch (error) { if (!isNetworkFailure(error)) throw error; return localWeeklyReport(await localAppointments(), date); }
    },
  });
}
function useInvalidate() { const qc = useQueryClient(); return () => { qc.invalidateQueries({ queryKey: ["appointments"] }); qc.invalidateQueries({ queryKey: ["report"] }); }; }
export function useSaveAppointment() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: async ({ id, data }: { id?: string; data: AppointmentCreate }) => {
      try {
        const saved = id ? await apiPut<Appointment>(`/appointments/${id}`, data) : await apiPost<Appointment>("/appointments", data);
        await cacheAppointments([saved]); return saved;
      } catch (error) { if (!isNetworkFailure(error)) throw error; return id ? offlineUpdate(id, data) : offlineCreate(data); }
    },
    onSuccess: async () => { invalidate(); if (navigator.onLine) void runOfflineSync(); },
  });
}
export function usePatchAppointment() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: AppointmentPatch }) => {
      try { const saved = await apiPatch<Appointment>(`/appointments/${id}`, data); await cacheAppointments([saved]); return saved; }
      catch (error) { if (!isNetworkFailure(error)) throw error; return offlineUpdate(id, data); }
    },
    onSuccess: async () => { invalidate(); if (navigator.onLine) void runOfflineSync(); },
  });
}
export function useDeleteAppointment() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: async (id: string) => {
      try { await apiDelete<void>(`/appointments/${id}`); }
      catch (error) { if (!isNetworkFailure(error)) throw error; await offlineDelete(id); }
    },
    onSuccess: async () => { invalidate(); if (navigator.onLine) void runOfflineSync(); },
  });
}
