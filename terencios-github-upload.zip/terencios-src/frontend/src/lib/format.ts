import { addDays, format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

const brlFmt = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
export const brl = (n: number) => brlFmt.format(n || 0);

export const localToday = () => format(new Date(), "yyyy-MM-dd");

export const shiftDate = (iso: string, days: number) => format(addDays(parseISO(iso), days), "yyyy-MM-dd");

export const fmtDate = (iso: string, pattern: string) => format(parseISO(iso), pattern, { locale: ptBR });

export function dayHeading(iso: string, today: string): string {
  if (iso === today) return "Hoje";
  if (iso === shiftDate(today, 1)) return "Amanhã";
  if (iso === shiftDate(today, -1)) return "Ontem";
  const s = fmtDate(iso, "EEEE, d 'de' MMMM");
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export const shortRange = (start: string, end: string) => `${fmtDate(start, "dd/MM")} a ${fmtDate(end, "dd/MM/yyyy")}`;

export function phoneDigits(phone: string): string {
  return phone.replace(/\D/g, "");
}

export function waLink(phone: string, text?: string): string {
  let d = phoneDigits(phone);
  if (d && d.length <= 11) d = `55${d}`;
  const q = text ? `?text=${encodeURIComponent(text)}` : "";
  return `https://wa.me/${d}${q}`;
}

export const mapsLink = (address: string) =>
  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;

export function parsePrice(v: string): number {
  const cleaned = v.replace(/[^\d,.-]/g, "");
  // "1.250,50" → 1250.50 ; "350,00" → 350 ; "350.5" → 350.5
  const normalized = cleaned.includes(",") ? cleaned.replace(/\./g, "").replace(",", ".") : cleaned;
  const n = Number(normalized);
  return Number.isFinite(n) ? n : NaN;
}
