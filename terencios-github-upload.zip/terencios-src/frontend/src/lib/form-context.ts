import { createContext, useContext } from "react";
import type { Appointment } from "@/lib/types";

export interface FormCtx {
  openForm: (appt?: Appointment) => void;
}

export const FormContext = createContext<FormCtx>({ openForm: () => {} });

export const useAppointmentForm = () => useContext(FormContext);
