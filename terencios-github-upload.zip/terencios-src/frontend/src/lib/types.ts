// Mirrors backend/models/appointment.py — keep in sync by hand.
export type Status = "agendado" | "concluido" | "cancelado";

export interface AppointmentCreate {
  client_name: string;
  client_phone: string;
  address: string;
  service_type: string;
  equipment: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  price: number;
  payment_method: string;
  is_paid: boolean;
  status: Status;
  notes: string;
}

export type AppointmentPatch = Partial<AppointmentCreate>;

export interface Appointment extends AppointmentCreate {
  id: string;
  created_at: string;
}

export interface TodayInfo {
  today: string;
  week_start: string;
}

export interface DayRevenue {
  date: string;
  label: string;
  faturado: number;
  count: number;
}

export interface MethodTotal {
  method: string;
  total: number;
  count: number;
}

export interface WeekHistory {
  week_start: string;
  week_end: string;
  faturado: number;
  recebido: number;
  count: number;
}

export interface WeeklyReport {
  week_start: string;
  week_end: string;
  is_current: boolean;
  faturado: number;
  recebido: number;
  a_receber: number;
  servicos_concluidos: number;
  ticket_medio: number;
  agendados: number;
  cancelados: number;
  days: DayRevenue[];
  payment_methods: MethodTotal[];
  history: WeekHistory[];
}

export const SERVICE_TYPES = [
  "Instalação",
  "Higienização / Limpeza",
  "Manutenção Preventiva",
  "Reparo / Conserto",
  "Carga de Gás",
  "Desinstalação / Remanejamento",
  "Outro",
];

export const PAYMENT_METHODS = [
  "Pix",
  "Dinheiro",
  "Cartão de Crédito",
  "Cartão de Débito",
  "Boleto",
  "A combinar",
];

export const STATUS_LABELS: Record<Status, string> = {
  agendado: "Agendado",
  concluido: "Concluído",
  cancelado: "Cancelado",
};
