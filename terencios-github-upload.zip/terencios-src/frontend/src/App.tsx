import { Routes, Route } from "react-router-dom";
import AppShell from "@/components/AppShell";
import Agenda from "@/pages/Agenda";
import Report from "@/pages/Report";
import History from "@/pages/History";

// One <Route> per page in src/pages; BrowserRouter already wraps this in main.tsx.
export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<Agenda />} />
        <Route path="/relatorio" element={<Report />} />
        <Route path="/historico" element={<History />} />
        <Route path="*" element={<Agenda />} />
      </Route>
    </Routes>
  );
}
