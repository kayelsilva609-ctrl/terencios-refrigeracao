import { Navigate, Route, Routes } from "react-router-dom";
import AppShell from "@/components/AppShell";
import Agenda from "@/pages/Agenda";
import Report from "@/pages/Report";
import History from "@/pages/History";
import Login from "@/pages/Login";
import { useAuth } from "@/lib/auth";

function ProtectedApp() {
  const { username, loading } = useAuth();
  if (loading) return <div className="min-h-screen grid place-items-center bg-[#0B1120] text-slate-300">Carregando...</div>;
  if (!username) return <Navigate to="/login" replace />;
  return <Routes><Route element={<AppShell />}><Route path="/" element={<Agenda />} /><Route path="/relatorio" element={<Report />} /><Route path="/historico" element={<History />} /><Route path="*" element={<Navigate to="/" replace />} /></Route></Routes>;
}

export default function App() {
  return <Routes><Route path="/login" element={<Login />} /><Route path="*" element={<ProtectedApp />} /></Routes>;
}
