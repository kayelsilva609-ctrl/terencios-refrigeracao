# Login e sincronização do Terencios Refrigeração

O projeto inclui dois acessos individuais, autenticação por senha com hash bcrypt, sessão em cookie HttpOnly, proteção das rotas da API e tela de login. Os dois usuários compartilham a mesma agenda no banco de dados da empresa.

## Ativação necessária antes do uso compartilhado

O código do APK sozinho não consegue compartilhar dados entre celulares. É necessário publicar a API e conectar um banco de dados online.

1. Publique a pasta `backend` em um serviço que execute FastAPI/Python e mantenha o processo ativo (por exemplo, Render ou Railway).
2. Configure um banco MongoDB persistente (por exemplo, MongoDB Atlas).
3. No serviço do backend, configure as variáveis descritas em `backend/.env.example`: `MONGO_URL`, `DB_NAME`, `JWT_SECRET_KEY`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `PARTNER_USERNAME`, `PARTNER_PASSWORD`, `COOKIE_SECURE=true` e `CORS_ORIGINS`.
4. `JWT_SECRET_KEY` deve ser um segredo aleatório longo. Não use a senha de nenhum dos usuários como segredo.
5. `CORS_ORIGINS` deve conter a origem exata do aplicativo/site, sem `*`. Para Android, a origem Capacitor pode variar conforme a configuração do projeto. O backend deve estar em HTTPS.
6. No GitHub, abra Settings → Secrets and variables → Actions → New repository secret. Crie `VITE_API_BASE_URL` com a URL HTTPS do backend terminando em `/api` (por exemplo, `https://api.seudominio.com/api`).
7. Gere novamente o APK pelo GitHub Actions. Instale a mesma versão nos dois celulares e cada pessoa entra com seu usuário e senha.

## Credenciais

- `ADMIN_USERNAME` / `ADMIN_PASSWORD`: primeiro acesso.
- `PARTNER_USERNAME` / `PARTNER_PASSWORD`: acesso do sócio.
- Usuários com pelo menos 3 caracteres; senhas com pelo menos 8 caracteres.
- Os usuários são criados automaticamente na primeira inicialização. Se já existirem, as senhas não são sobrescritas pelas variáveis de ambiente.
- Não coloque senhas no código nem as envie em conversas.

## Funcionamento offline

Depois de entrar uma primeira vez com internet, o app mantém a agenda em cache local. Sem internet, as alterações ficam na fila local daquele celular e são enviadas quando a conexão voltar. O outro celular só recebe as alterações depois que o primeiro conseguir sincronizar com o servidor. Dois celulares totalmente offline não conseguem trocar alterações em tempo real. Entre na conta e sincronize antes de ficar sem internet.

## Limites desta etapa

O código do login e a proteção da API estão preparados, mas a hospedagem, o banco de dados e as variáveis secretas ainda precisam ser configurados. Até isso acontecer, o login compartilhado não estará ativo. Não gere nem distribua o APK final antes de configurar `VITE_API_BASE_URL` e publicar o backend.
